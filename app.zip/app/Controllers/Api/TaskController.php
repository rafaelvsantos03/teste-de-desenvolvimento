<?php

namespace App\Controllers;

use App\Models\TaskModel;

class TaskController extends BaseController
{
    protected $helpers = ['form'];

    // Listar tarefas
    public function index()
    {
        $model = new TaskModel();
        $data['tasks'] = $model->findAll();

        return view('tasks/index', $data);
    }

    // Formulário de criação
    public function create()
    {
        return view('tasks/create');
    }

    // Salvar nova tarefa
    public function store()
    {
        $rules = [
            'title' => 'required|min_length[3]',
            'status' => 'required|in_list[pendente,em andamento,concluída]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $model = new TaskModel();
        $model->save([
            'title' => $this->request->getPost('title'),
            'description' => $this->request->getPost('description'),
            'status' => $this->request->getPost('status')
        ]);

        return redirect()->to('/')->with('success', 'Tarefa criada com sucesso!');
    }

    // Formulário de edição
    public function edit($id)
    {
        $model = new TaskModel();
        $data['task'] = $model->find($id);

        if (!$data['task']) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        return view('tasks/edit', $data);
    }

    // Atualizar tarefa
    public function update($id)
    {
        $rules = [
            'title' => 'required|min_length[3]',
            'status' => 'required|in_list[pendente,em andamento,concluída]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $model = new TaskModel();
        $model->update($id, [
            'title' => $this->request->getPost('title'),
            'description' => $this->request->getPost('description'),
            'status' => $this->request->getPost('status')
        ]);

        return redirect()->to('/')->with('success', 'Tarefa atualizada com sucesso!');
    }

    // Excluir tarefa
    public function delete($id)
    {
        $model = new TaskModel();
        $model->delete($id);

        return redirect()->to('/')->with('success', 'Tarefa excluída com sucesso!');
    }
}
