<?= $this->extend('layout') ?>
<?= $this->section('content') ?>

<div class="container mt-5">
    <h2>Editar Tarefa</h2>
    <form method="post" action="/tasks/update/<?= $task['id'] ?>">
        <?= csrf_field() ?>
        <div class="mb-3">
            <label for="title" class="form-label">Título</label>
            <input type="text" name="title" class="form-control" value="<?= $task['title'] ?>">
        </div>
        <div class="mb-3">
            <label for="description" class="form-label">Descrição</label>
            <textarea name="description" class="form-control"><?= $task['description'] ?></textarea>
        </div>
        <div class="mb-3">
            <label for="status" class="form-label">Status</label>
            <select name="status" class="form-select">
                <option value="pendente" <?= $task['status'] == 'pendente' ? 'selected' : '' ?>>Pendente</option>
                <option value="em andamento" <?= $task['status'] == 'em andamento' ? 'selected' : '' ?>>Em andamento</option>
                <option value="concluída" <?= $task['status'] == 'concluída' ? 'selected' : '' ?>>Concluída</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Atualizar</button>
        <a href="/" class="btn btn-secondary">Cancelar</a>
    </form>
</div>

<?= $this->endSection() ?>

