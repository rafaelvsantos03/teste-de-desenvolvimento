<?= $this->extend('layout') ?>
<?= $this->section('content') ?>

<div class="container mt-5">
    <h2>Criar Tarefa</h2>
    <form method="post" action="/tasks/store">
        <?= csrf_field() ?>
        <div class="mb-3">
            <label for="title" class="form-label">Título</label>
            <input type="text" name="title" class="form-control" value="<?= old('title') ?>">
        </div>
        <div class="mb-3">
            <label for="description" class="form-label">Descrição</label>
            <textarea name="description" class="form-control"><?= old('description') ?></textarea>
        </div>
        <div class="mb-3">
            <label for="status" class="form-label">Status</label>
            <select name="status" class="form-select">
                <option value="pendente">Pendente</option>
                <option value="em andamento">Em andamento</option>
                <option value="concluída">Concluída</option>
            </select>
        </div>
        <button type="submit" class="btn btn-success">Salvar</button>
        <a href="/" class="btn btn-secondary">Cancelar</a>
    </form>
</div>

<?= $this->endSection() ?>

